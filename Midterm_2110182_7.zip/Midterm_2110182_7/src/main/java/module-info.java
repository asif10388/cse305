module com.csc305.midterm_2110182_7 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.csc305.midterm_2110182_7 to javafx.fxml;
    exports com.csc305.midterm_2110182_7;
}